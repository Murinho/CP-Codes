#include<bits/stdc++.h>
using namespace std;

const int N=22*22*22;
int cnt1[N][N],cnt2[N][N];
vector<array<int,3>>v[N][2][2][2];

int main(){
    cin.tie(0)->sync_with_stdio(0);
    int n;
    cin>>n;
    string s[n][n];
    char c;
    for(int i=0;i<n;i++){
        cin>>c;
        for(int j=0;j<n;j++)cin>>s[i][j];
    }
    for(int i=-21;i<=21;i++)for(int j=-21;j<=21;j++)for(int k=-21;k<=21;k++)
        v[i*i+j*j+k*k][(i%2+2)%2][(j%2+2)%2][(k%2+2)%2].push_back({i,j,k});
    for(int i1=0;i1<n;i1++)for(int j1=0;j1<n;j1++)for(int k1=0;k1<n;k1++){
        if(s[i1][j1][k1]!='B')continue;
        for(int i2=0;i2<n;i2++)for(int j2=0;j2<n;j2++)for(int k2=0;k2<n;k2++){
            if(s[i2][j2][k2]!='P')continue;
            int i=i1-i2,j=j1-j2,k=k1-k2;
            int r=i*i+j*j+k*k;
            i=i1+i2,j=j1+j2,k=k1+k2;
            for(auto [x,y,z]:v[r][i%2][j%2][k%2]){
                x=(x+i)/2;
                y=(y+j)/2;
                z=(z+k)/2;
                if(0<=x&&x<n&&0<=y&&y<n&&0<=z&&z<n&&s[x][y][z]=='A'){
                    cnt1[x*n*n+y*n+z][i2*n*n+j2*n+k2]++;
                }
            }
        }
    }
    for(int i1=0;i1<n;i1++)for(int j1=0;j1<n;j1++)for(int k1=0;k1<n;k1++){
        if(s[i1][j1][k1]!='C')continue;
        for(int i2=0;i2<n;i2++)for(int j2=0;j2<n;j2++)for(int k2=0;k2<n;k2++){
            if(s[i2][j2][k2]!='A')continue;
            int i=i1-i2,j=j1-j2,k=k1-k2;
            int r=i*i+j*j+k*k;
            i=i1+i2,j=j1+j2,k=k1+k2;
            for(auto [x,y,z]:v[r][i%2][j%2][k%2]){
                x=(x+i)/2;
                y=(y+j)/2;
                z=(z+k)/2;
                if(0<=x&&x<n&&0<=y&&y<n&&0<=z&&z<n&&s[x][y][z]=='P'){
                    cnt2[i2*n*n+j2*n+k2][x*n*n+y*n+z]++;
                }
            }
        }
    }
    long long res=0;
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++){
            res+=cnt1[i][j]*cnt2[i][j];
        }
    cout<<res<<"\n";
}
